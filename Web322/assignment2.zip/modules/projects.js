const projectData = require("../data/projectData");
const sectorData = require("../data/sectorData");

let projects = []; // This will store processed project data

// Initialize the projects array by merging sector names
function initialize() {
    return new Promise((resolve, reject) => {
        try {
            projects = projectData.map(project => {
                let sector = sectorData.find(sec => sec.id === project.sector_id);
                return { ...project, sector: sector ? sector.sector_name : "Unknown" };
            });
            resolve(); // No data is returned, just a signal that processing is done
        } catch (error) {
            reject("Failed to initialize project data");
        }
    });
}

// Get all projects
function getAllProjects() {
    return new Promise((resolve, reject) => {
        projects.length > 0 ? resolve(projects) : reject("No projects available");
    });
}

//  Get a project by ID
function getProjectById(projectId) {
    return new Promise((resolve, reject) => {
        let project = projects.find(p => p.id == projectId);
        project ? resolve(project) : reject("Project not found");
    });
}

//  Get projects by sector name (case-insensitive search)
function getProjectsBySector(sector) {
    return new Promise((resolve, reject) => {
        let filteredProjects = projects.filter(p =>
            p.sector.toLowerCase().includes(sector.toLowerCase())
        );
        filteredProjects.length > 0 ? resolve(filteredProjects) : reject("No projects found in this sector");
    });
}

// Export all functions for use in server.js
module.exports = { initialize, getAllProjects, getProjectById, getProjectsBySector };
