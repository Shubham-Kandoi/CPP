/******************************************************************************** 
*  WEB322 – Assignment 02 
*  
*  I declare that this assignment is my own work in accordance with Seneca's 
*  Academic Integrity Policy: 
*  
*  https://www.senecapolytechnic.ca/about/policies/academic-integrity-policy.html 
*  
*  Name: [Shubham Dharmendrabhai Kandoi]   Student ID: [144838232]   Date: [05-02-2025] 
* 
********************************************************************************/

const express = require("express");
const projectData = require("./modules/projects");

const app = express();
const PORT = 3000;

// Initialize project data before starting the server
projectData.initialize()
    .then(() => {
        // Home Route
        app.get("/", (req, res) => {
            res.send("Assignment 2: [Shubham Dharmendrabhai Kandoi] - [144838232]");
        });

        // Get All Projects
        app.get("/solutions/projects", (req, res) => {
            projectData.getAllProjects()
                .then(data => res.json(data))
                .catch(err => res.status(500).send(err));
        });

        // Get a Project by ID
        app.get("/solutions/projects/id-demo", (req, res) => {
            projectData.getProjectById(18) // Example project ID
                .then(data => res.json(data))
                .catch(err => res.status(404).send(err));
        });

        // Get Projects by Sector Name
        app.get("/solutions/projects/sector-demo", (req, res) => {
            projectData.getProjectsBySector("Transportation") // Example sector name
                .then(data => res.json(data))
                .catch(err => res.status(404).send(err));
        });

        // Start the server
        app.listen(PORT, () => {
            console.log(`Server running on port ${PORT}`);
        });
    })
    .catch(err => {
        console.error("Error initializing data:", err);
    });