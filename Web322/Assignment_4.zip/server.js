/********************************************************************************
 *  WEB322 – Assignment 03
 *  
 *  I declare that this assignment is my own work in accordance with Seneca's
 *  Academic Integrity Policy:
 *  
 *  https://www.senecapolytechnic.ca/about/policies/academic-integrity-policy.html
 *  
 *  Name: Shubham Dharmendrabhai Kandoi
 *  Student ID: 144838232
 *  Date: 17-02-2025
 * 
 ********************************************************************************/

const express = require("express");
const path = require("path");
const projectData = require("./modules/projects.js");

const app = express();
const PORT = process.env.PORT || 3000;

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));


// Serve static files
app.use(express.static(path.join(__dirname, "public")));

projectData.initialize()
.then(() => console.log("Project Data Initialized"))
.catch(err => console.error("Initialization failed:", err));



    // Home Page
    app.get("/", async (req, res) => {
        try {
            const allProjects = await projectData.getAllProjects();
            if (!allProjects || allProjects.length === 0) {
                throw new Error("No projects found");
            }
            const projects = allProjects.slice(0, 5);
            res.render("home", { projects, page: "/" });
        } catch (err) {
            console.error("Error in / route:", err);
            res.status(500).render("404", { message: "Error loading home page" });
        }
    });
    
    // About Page
    app.get("/about", (req, res) => {
        res.render("about", { page: "/about" });
    });

    // Getting All Projects or Filter by Sector
    app.get("/solutions/projects", async (req, res) => {
        try {
            let projects;
            if (req.query.sector) {
                projects = await projectData.getProjectsBySector(req.query.sector);
                if (projects.length === 0) {
                    return res.status(404).render("404", { message: "No projects found in this sector." });
                }
            } else {
                projects = await projectData.getAllProjects();
            }
            res.render("projects", { projects, page: "/solutions/projects" });
        } catch (err) {
            res.status(500).render("404", { message: "Error loading projects" });
        }
    });

    // Getting Project by ID
    app.get("/solutions/projects/:id", async (req, res) => {
        try {
            const project = await projectData.getProjectById(parseInt(req.params.id));
            if (!project) {
                return res.status(404).render("404", { message: "Project not found." });
            }
            res.render("project", { project, page: "" });
        } catch (err) {
            res.status(404).render("404", { message: "Error loading project" });
        }
    });

    // 404 Page
    app.use((req, res) => {
        res.status(404).render("404", { message: "Page not found." });
    });
    
    if (require.main === module) {
        app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
    }
    
    module.exports = app;