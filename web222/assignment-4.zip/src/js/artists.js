/**
 * artists.js
 *
 * The app's list of Artists
 */

window.artists = [
  {
    artistId: "AID-1",
    name: "KK",
    urls: [
      { url: "https://www.instagram.com/kk_live_now/", name: "Instagram" },
      { url: "https://en.wikipedia.org/wiki/KK_(singer)", name: "Wikipedia" }
    ],
    imageUrl: "K.K.jpeg"
  },
  {
    artistId: "AID-2",
    name: "Shreya Ghosal",
    urls: [
      { url: "https://shreyaghoshal.com", name: "Official Website" },
      { url: "https://www.instagram.com/shreyaghoshal/", name: "Instagram" },
      { url: "https://en.wikipedia.org/wiki/Shreya_Ghoshal", name: "Wikipedia" }
    ],
    imageUrl: "Shreya_Ghosal.jpg"
  },
  {
    artistId: "AID-3",
    name: "Sunidhi Chauhan",
    urls: [
      { url: "https://www.instagram.com/sunidhichauhan5/", name: "Instagram" },
      { url: "https://x.com/sunidhichauhan5", name: "Twitter" },
      { url: "https://en.wikipedia.org/wiki/Sunidhi_Chauhan", name: "Wikipedia" }
    ],
    imageUrl: "Sunidhi_Chauhan.jpg"
  },
  {
    artistId: "AID-4",
    name: "Lata Mangeshkar",
    urls: [
      { url: "https://www.instagram.com/lata_mangeshkar/", name: "Instagram" },
      { url: "https://x.com/mangeshkarlata", name: "Twitter" },
      { url: "https://en.wikipedia.org/wiki/Lata_Mangeshkar", name: "Wikipedia" }
    ],
    imageUrl: "Lata_Mangeshkar.jpg"
  }
];
