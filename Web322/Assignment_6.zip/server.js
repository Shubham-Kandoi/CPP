// server.js
/********************************************************************************
*  WEB322 – Assignment 06
*  
*  I declare that this assignment is my own work in accordance with Seneca's
*  Academic Integrity Policy:
*  https://www.senecapolytechnic.ca/about/policies/academic-integrity-policy.html
*  
*  Name: Your Name   Student ID: YourID   Date: Submission Date
********************************************************************************/

const express = require("express");
const path = require("path");
const dotenv = require("dotenv");
const clientSessions = require("client-sessions");
const projectData = require("./modules/projects");
const authData = require("./modules/auth-service");
const app = express();
const HTTP_PORT = process.env.PORT || 3000;

dotenv.config();

app.engine("ejs", require("ejs").__express);
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));


app.use(express.static("public"));
app.use(express.urlencoded({ extended: true }));

app.use(
  clientSessions({
    cookieName: "session",
    secret: "assignment6secret",
    duration: 2 * 60 * 1000,
    activeDuration: 1000 * 60,
  })
);

app.use((req, res, next) => {
  res.locals.session = req.session;
  next();
});

function ensureLogin(req, res, next) {
  if (!req.session.user) {
    res.redirect("/login");
  } else {
    next();
  }
}

app.get("/", async (req, res) => {
  try {
    const allProjects = await projectData.getAllProjects();
    const projects = allProjects.slice(0, 6);
    res.render("home", { projects, page: "/" });
  } catch (err) {
    console.error("Error loading home page:", err);
    res.status(500).render("500", { message: "Error loading home page" });
  }
});

app.get("/about", (req, res) => {
  res.render("about", { page: "/about" });
});

app.get("/solutions/projects", async (req, res) => {
  try {
    let projects;
    if (req.query.sector) {
      const sector = req.query.sector;
      projects = await projectData.getProjectsBySector(sector);
      if (!projects || projects.length === 0) {
        return res.status(404).render("404", { message: "No projects found in this sector." });
      }
    } else {
      projects = await projectData.getAllProjects();
    }
    res.render("projects", { projects, page: "/solutions/projects" });
  } catch (err) {
    console.error("Error loading projects:", err);
    res.status(500).render("500", { message: "Error loading projects" });
  }
});

app.get("/solutions/project/:id", async (req, res) => {
  try {
    const project = await projectData.getProjectById(req.params.id);
    res.render("project", { project, page: "/solutions/projects" });
  } catch (err) {
    res.status(404).render("404", { message: "Project not found." });
  }
});

app.get("/solutions/addProject", ensureLogin, async (req, res) => {
  try {
    const sectors = await projectData.getAllSectors();
    res.render("addProject", { sectors, page: "/solutions/addProject" });
  } catch (err) {
    res.status(500).render("500", { message: `Error loading sectors: ${err.message}` });
  }
});


app.get("/solutions/editProject/:id", ensureLogin, async (req, res) => {
  try {
    const project = await projectData.getProjectById(req.params.id);
    res.render("editProject", { project, page: "/solutions/editProject" });
  } catch {
    res.status(500).render("500", { message: "Project not found." });
  }
});

app.post("/solutions/editProject/:id", ensureLogin, async (req, res) => {
  try {
    await projectData.editProject(req.params.id, req.body);
    res.redirect("/solutions/projects");
  } catch (err) {
    res.status(500).render("500", { message: "Failed to update project." });
  }
});

app.get("/solutions/deleteProject/:id", ensureLogin, async (req, res) => {
  try {
    await projectData.deleteProject(req.params.id);
    res.redirect("/solutions/projects");
  } catch (err) {
    res.status(500).render("500", { message: "Failed to delete project." });
  }
});

app.get("/login", (req, res) => {
  res.render("login", { errorMessage: "", userName: "", page: "/login" });
});

app.post("/login", (req, res) => {
  req.body.userAgent = req.get("User-Agent");
  authData
    .checkUser(req.body)
    .then((user) => {
      req.session.user = {
        userName: user.userName,
        email: user.email,
        loginHistory: user.loginHistory,
      };
      res.redirect("/solutions/projects");
    })
    .catch((err) => {
      res.render("login", {
        errorMessage: err,
        userName: req.body.userName,
        page: "/login",
      });
    });
});

app.get("/register", (req, res) => {
  res.render("register", {
    errorMessage: "",
    successMessage: "",
    userName: "",
    page: "/register",
  });
});

app.post("/register", (req, res) => {
  authData
    .registerUser(req.body)
    .then(() => {
      res.render("register", {
        successMessage: "User created",
        errorMessage: "",
        userName: "",
        page: "/register",
      });
    })
    .catch((err) => {
      res.render("register", {
        errorMessage: err,
        successMessage: "",
        userName: req.body.userName,
        page: "/register",
      });
    });
});

app.get("/logout", (req, res) => {
  req.session.reset();
  res.redirect("/");
});

app.get("/userHistory", ensureLogin, (req, res) => {
  res.render("userHistory", { page: "/userHistory" });
});

app.use((req, res) => {
  res.status(404).render("404", {
    page: "/404",
    message: null 
  });
});


projectData
  .initialize()
  .then(authData.initialize)
  .then(() => {
    app.listen(HTTP_PORT, () => {
      console.log("App listening on port " + HTTP_PORT);
    });
  })
  .catch((err) => {
    console.log("Unable to start server: " + err);
  });