module.exports = {
  content: ["./views/**/*.html", "./public/**/*.js"],
  theme: {
    extend: {},
  },
  plugins: [require("@tailwindcss/typography"), require("daisyui")],
  daisyui: {
    themes: ["dim"], // You can change this theme (e.g., "cupcake", "forest")
  },
};
