/**
 * songs.js
 *
 * The app's songs
 */

window.songs = [
  // KK Songs
  {
    songId: "SID-101",
    artistId: "AID-1",
    title: "Pyaar Ke Pal",
    year: "1999",
    duration: 356, // 5:56 in seconds
    url: "https://youtu.be/bB2MA2Y46bU?si=RA56ms_SWZVx8yGE",
    explicit: false,
    imageUrl: "1.1.jpg"
  },
  {
    songId: "SID-102",
    artistId: "AID-1",
    title: "Sach Keh Raha Hai",
    year: "2001",
    duration: 368, // 6:08 in seconds
    url: "https://youtu.be/PizHX6Kuy1M?si=K3wdbkcCxFwSWS0H",
    explicit: false,
    imageUrl: "1.2.jpg"
  },
  {
    songId: "SID-103",
    artistId: "AID-1",
    title: "Kya Mujhe Pyaar Hai",
    year: "2006",
    duration: 263, // 4:23 in seconds
    url: "https://youtu.be/Gg6NMU4ivXM?si=bU7b1aRaOmkHAZkn",
    explicit: true,
    imageUrl: "1.3.jpg"
  },
  {
    songId: "SID-104",
    artistId: "AID-1",
    title: "Ajab Si",
    year: "2007",
    duration: 260, // 4:20 in seconds
    url: "https://youtu.be/7KKVb0_IdD4?si=pSofbO5YzIxQPxsK",
    explicit: false,
    imageUrl: "https://c.saavncdn.com/179/Om-Shanti-Om-Hindi-2007-20221203122509-500x500.jpg"
  },
  {
    songId: "SID-105",
    artistId: "AID-1",
    title: "I Am In Love",
    year: "2010",
    duration: 305, // 5:05 in seconds
    url: "https://youtu.be/DMLrGfMxOQA?si=g4CZ8kpEuiBhnLn-",
    explicit: true,
    imageUrl: "1.5.jpg"
  },

  // Shreya Ghosal Songs
  {
    songId: "SID-106",
    artistId: "AID-2",
    title: "Silsila Yeh Chahat Ka ",
    year: "2002",
    duration: 307, // 5:07 in seconds
    url: "https://youtu.be/yWNzKpUVkN8?si=1xa6mS--Cq7ZpE-Q",
    explicit: false,
    imageUrl: "2.1.jpg"
  },
  {
    songId: "SID-107",
    artistId: "AID-2",
    title: "Agar Tum Mil Jao",
    year: "2005",
    duration: 360, // 6:00 in seconds
    url: "https://youtu.be/FH-oV5nXblA?si=4G0V0c6tfTX6HPv_",
    explicit: false,
    imageUrl: "2.2.jpg"
  },
  {
    songId: "SID-108",
    artistId: "AID-2",
    title: "Piyu Bole",
    year: "2005",
    duration: 298, // 4:58 in seconds
    url: "https://youtu.be/ZAkr0KFFLLs?si=cCZeBaqRZo9iNjOk",
    explicit: false,
    imageUrl: "2.3.jpg"
  },
  {
    songId: "SID-109",
    artistId: "AID-2",
    title: "Saibo",
    year: "2011",
    duration: 136, // 2:16 in seconds
    url: "https://youtu.be/GtNrQy90Ih4?si=YweVeZL4gRP-w_kL",
    explicit: false,
    imageUrl: "2.4.jpg"
  },
  {
    songId: "SID-110",
    artistId: "AID-2",
    title: "Kashmir",
    year: "2023",
    duration: 207, // 3:37 in seconds
    url: "https://youtu.be/I5eSgUJ5jAw?si=SxmRwAoEV7LuQyVp",
    explicit: true,
    imageUrl: "2.5.jpg"
  },

  // Sunidhi Chauhan Songs
  {
    songId: "SID-111",
    artistId: "AID-3",
    title: "Sajna Ve Sajna",
    year: "2003",
    duration: 234, // 3:54 in seconds
    url: "https://youtu.be/yR5B-00peGQ?si=Pc0wB9SRQRrt4pOE",
    explicit: false,
    imageUrl: "3.1.jpg"
  },
  {
    songId: "SID-112",
    artistId: "AID-3",
    title: "Bhaage Re Mann",
    year: "2003",
    duration: 268, // 4:28 in seconds
    url: "https://youtu.be/dCosqNGw2ck?si=-wXVOe5gaCyKUqSd",
    explicit: false,
    imageUrl: "3.2.jpg"
  },
  {
    songId: "SID-113",
    artistId: "AID-3",
    title: "Chor Bazaari",
    year: "2009",
    duration: 136, // 4:23 in seconds
    url: "https://youtu.be/hsTQKwZEMQE?si=GXYczZZJt5Ur1an_",
    explicit: false,
    imageUrl: "3.3.jpg"
  },
  {
    songId: "SID-114",
    artistId: "AID-3",
    title: "Surili Akhiyon Wale",
    year: "2010",
    duration: 331, // 5:31 in seconds
    url: "https://youtu.be/0dUdnlAps9Q?si=GWMremldlUHlMg_F",
    explicit: false,
    imageUrl: "3.4.jpg"
  },
  {
    songId: "SID-115",
    artistId: "AID-3",
    title: "Sheila Ki Jawani",
    year: "2010",
    duration: 270, // 4:30 in seconds
    url: "https://youtu.be/ZTmF2v59CtI?si=uqi4-brNW45_9sqN",
    explicit: true,
    imageUrl: "3.5.jpg"
  },

  //Lata Mangeshkar Songs
  {
    songId: "SID-116",
    artistId: "AID-4",
    title: "Aaj Phir Jeene Ki Tamanna Hai",
    year: "1965",
    duration: 224, // 3:44 in seconds
    url: "https://youtu.be/BpLyDTEw3Z4?si=o9wO-pavkGqwqJ10",
    explicit: false,
    imageUrl: "4.1.jpg"
  },
  {
    songId: "SID-117",
    artistId: "AID-4",
    title: "Panna Ki Tamanna Hai",
    year: "1973",
    duration: 411, // 6:51 in seconds
    url: "https://youtu.be/OmQtnMI0M5I?si=QC1EfKJQ6W9q-CK9",
    explicit: false,
    imageUrl: "4.2.jpg"
  },
  {
    songId: "SID-118",
    artistId: "AID-4",
    title: "Jai Jai Shiv Shankar",
    year: "1974",
    duration: 351, // 5:51 in seconds
    url: "https://youtu.be/Mpy0UzbHNr0?si=FAAx6w7WQKlr1ODP",
    explicit: false,
    imageUrl: "4.3.jpg"
  },
  {
    songId: "SID-119",
    artistId: "AID-4",
    title: "Jiya Jale",
    year: "1998",
    duration: 262, // 4:22 in seconds
    url: "https://youtu.be/M-2nlaOQQSQ?si=BJDc0JpDCsp8YTaS",
    explicit: false,
    imageUrl: "4.4.jpg"
  },
  {
    songId: "SID-120",
    artistId: "AID-4",
    title: "Luka Chuppi",
    year: "2005",
    duration: 251, // 4:11 in seconds
    url: "https://youtu.be/FFpgYjL2aJo?si=zcMh3K2hSMZ9_Pkz",
    explicit: false,
    imageUrl: "4.5.jpg"
  },
  {
    songId: "SID-121",
    artistId: "AID-4",
    title: "Naam Ghoom Jayega",
    year: "1977",
    duration: 311, // 5:11 in seconds
    url: "https://youtu.be/Hziy9jXQ8VQ?si=-We8YpM7KYfe2tYz",
    explicit: false,
    imageUrl: "4.6.jpg"
  },
  {
    songId: "SID-122",
    artistId: "AID-4",
    title: "Tere Liye",
    year: "2004",
    duration: 333, // 5:33 in seconds
    url: "https://youtu.be/jo6iAkSoraY?si=KuegIcSHHsGjZBzI",
    explicit: false,
    imageUrl: "4.7.jpg"
  },
  {
    songId: "SID-123",
    artistId: "AID-4",
    title: "Ajib Dastan Hai Yeh",
    year: "1960",
    duration: 288, // 4:48 in seconds
    url: "https://youtu.be/AU-hut9lGQ4?si=6EmeYcNZsUD18Xlm",
    explicit: false,
    imageUrl: "4.8.jpg"
  },
  {
    songId: "SID-124",
    artistId: "AID-4",
    title: "Aap Ki Aankhon Mein Kuch",
    year: "1978",
    duration: 231, // 3:51 in seconds
    url: "https://youtu.be/daxuKHBWiKE?si=pz6OCvUTrcNHc0IC",
    explicit: false,
    imageUrl: "4.9.jpg"
  },
  {
    songId: "SID-125",
    artistId: "AID-4",
    title: "Tere Bina Zindagi Se",
    year: "1975",
    duration: 422, // 7:02 in seconds
    url: "https://youtu.be/8-HnmVg0-O8?si=bRbpYBubc4NgrFZC",
    explicit: false,
    imageUrl: "4.10.jpg"
  }
];
