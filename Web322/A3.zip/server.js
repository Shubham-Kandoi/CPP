/********************************************************************************
 *  WEB322 – Assignment 03
 *  
 *  I declare that this assignment is my own work in accordance with Seneca's
 *  Academic Integrity Policy:
 *  
 *  https://www.senecapolytechnic.ca/about/policies/academic-integrity-policy.html
 *  
 *  Name: Shubham Dharmendrabhai Kandoi
 *  Student ID: 144838232
 *  Date: 17-02-2025
 * 
 ********************************************************************************/

const express = require("express");
const path = require("path");
const projectData = require("./modules/projects");

const app = express();
const PORT = 3000;

// Serve static files
app.use(express.static('public'));

projectData.initialize().then(() => {

    app.use(express.static(path.join(__dirname, "/public/css/main.css")));


    // Home Page
    app.get("/", (req, res) => {
        res.sendFile(path.join(__dirname, "views/home.html"));
    });

    // About Page
    app.get("/about", (req, res) => {
        res.sendFile(path.join(__dirname, "views/about.html"));
    });

    // Get All Projects or Filter by Sector
    app.get("/solutions/projects", (req, res) => {
        const sector = req.query.sector;
        if (sector) {
            projectData.getProjectsBySector(sector)
                .then(data => res.json(data))
                .catch(err => res.status(404).send(err));
        } else {
            projectData.getAllProjects()
                .then(data => res.json(data))
                .catch(err => res.status(500).send(err));
        }
    });

    // Get Project by ID
    app.get("/solutions/projects/:id", (req, res) => {
        const projectId = parseInt(req.params.id);
        projectData.getProjectById(projectId)
            .then(data => res.json(data))
            .catch(err => res.status(404).send(err));
    });

    // 404 Page
    app.use((req, res) => {
        res.status(404).sendFile(path.join(__dirname, "views/404.html"));
    });

    // Start the server
    app.listen(PORT, () => {
        console.log(`Server running on port ${PORT}`);
    });

}).catch(err => {
    console.error("Error initializing data:", err);
});
